# TheoryInAction
 Unity course project - Programming theory in action

From Unity Learn - Pathway: Junior Programmer, Mission: Apply object-oriented principles

Based on the project from Create with Code: Unit 3 / Prototype 3 - Bonus features

(New scene is named TheoryInAction)
